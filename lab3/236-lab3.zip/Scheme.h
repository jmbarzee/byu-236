/*
 * Scheme.h
 *
 *  Created on: Jul 22, 2015
 *      Author: jacobmb
 */

#ifndef SCHEME_H_
#define SCHEME_H_

#include <vector>
#include <string>

using namespace std;

class Scheme: public vector<string> {
public:

};

#endif /* SCHEME_H_ */
